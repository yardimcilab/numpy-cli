import click
import pandas
import yaml
import sys

def process_dataframe(df, python_command):
    # Execute the provided Python command on the DataFrame 'df'
    local_vars = {'df': df}
    exec(python_command, globals(), local_vars)
    return local_vars['df']

@click.group(invoke_without_command=True)
@click.pass_context
@click.argument('python_command')
@click.option('--orient-in', type=click.Choice(['columns', 'index', 'tight']), default='columns')
@click.option('--from_raw_stdin', is_flag = True, default = False, help="Use raw stdin as input to DataFrame.from_dict(), otherwise call yaml.safe_load on it first")
def cli(ctx, python_command, orient_in, from_raw_stdin):
    ctx.ensure_object(dict)
    stdin = sys.stdin
    if not from_raw_stdin:
        stdin = yaml.safe_load(stdin)
    df = pandas.DataFrame.from_dict(stdin, orient=orient_in)

    df = process_dataframe(df, python_command)
    ctx.obj["df"] = df

@cli.group(name='to')
@click.pass_context
def to_group(ctx):
    pass

@to_group.command(name='dict')
@click.option('--orient', type=click.Choice(['dict', 'list', 'series', 'split', 'tight', 'records', 'index']), default='dict')
@click.option('--index', is_flag = True, default = True)
@click.option('--yaml', is_flag = True, default = True)
@click.pass_context
def to_dict(ctx, orient, index, yaml):
    df = ctx.obj['df']
    stdout = df.to_dict(orient=orient, index=index)
    if yaml:
        stdout = yaml.dump(stdout)
    click.echo(stdout)

if __name__ == "__main__":
    cli(obj={})
